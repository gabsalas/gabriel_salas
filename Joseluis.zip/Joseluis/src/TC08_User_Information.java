import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC08_User_Information {
	public static void main(String[] arg)
	{
		String[] select = new String[6] ;
		int cont=0,number_items=6;
		select[0]= "Sauce Labs Backpack";
		select[1]= "Sauce Labs Bike Light";
		select[2]= "Sauce Labs Bolt T-Shirt";
		select[3]= "Sauce Labs Fleece Jacket";
		select[4]= "Sauce Labs Onesie";
		select[5]= "Test.allTheThings() T-Shirt (Red)";
		
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\casa\\eclipse-workspace\\driver\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Log_in log= new Log_in();
		Shop_Cart log2= new Shop_Cart();
		driver.get("https://www.saucedemo.com");
		System.out.print(log.log_in("standard_user","secret_sauce",driver )+"\n");
		Select_Item item= new Select_Item();
		do
		{
		
		item.Select_Item(select[cont], driver);
		cont++;
		}while(cont<number_items);
		cont=0;
		Shop_Cart.Shop_Cart(driver);
		do
		{
		
		System.out.print(Check_Item.Check(select[cont], driver,number_items)+"\n");
		cont++;
		}while(cont<number_items);
		System.out.print(Checkout.Checkout(driver));
		//driver.findElement(By.xpath("//*[@id='checkout_info_container']/div/form/div[2]/input")).click();
		User_data user = new User_data();
		System.out.print(user.data(driver, "Gab", "Salas","45599")); 
		
		driver.close();
		
		
	}


	
}
