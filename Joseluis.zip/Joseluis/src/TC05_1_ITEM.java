import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TC05_1_ITEM {
	public static void main(String[] arg)
	{
		String select ;
		select= "Test.allTheThings() T-Shirt (Red)";
		System.setProperty("webdriver.chrome.driver","C:\\Users\\casa\\eclipse-workspace\\driver\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Log_in log= new Log_in();
		Shop_Cart log2= new Shop_Cart();
		driver.get("https://www.saucedemo.com");
		System.out.print(log.log_in("standard_user","secret_sauce",driver )+"\n");
		Select_Item item= new Select_Item();
		item.Select_Item(select, driver);
		log2.Shop_Cart(driver);
		System.out.print(select+ " " + Check_Item.Check(select, driver,6));
		driver.close();
		
	}
}


/*
Sauce Labs Backpack
//*[@id="inventory_container"]/div/div[1]/div[3]/button

Sause Labs Bike Ligth

//*[@id="inventory_container"]/div/div[2]/div[3]/button


Sause Labs Bolt T-sHIRT
//*[@id="inventory_container"]/div/div[3]/div[3]/button

sAUCE Labs Fleece Jacket
//*[@id="inventory_container"]/div/div[4]/div[3]/button

Sause Labs Onesie
//*[@id="inventory_container"]/div/div[5]/div[3]/button

Test.allTheThings() T-Shrit(Red)
//*[@id="inventory_container"]/div/div[6]/div[3]/button 

*/