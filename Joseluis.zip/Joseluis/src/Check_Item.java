import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Check_Item {
	public static String Check(String item,WebDriver driver, int total)
	{
		int count=0;
		do
		{
			try
			{
			if(	driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")) != null)
			{
				
				if(	driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")).getText().equals(item))
				{
					return (driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")).getText()+ " Found");
			/*switch(item)
			{
				case "Sauce Labs Backpack" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[1]/div[3]/button")).click();
					break;
				case "Sauce Labs Bike Light" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[2]/div[3]/button")).click();
					break;
				case "Sauce Labs Bolt T-Shirt" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[3]/div[3]/button")).click();
					break;
				case "Sauce Labs Fleece Jacket" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[4]/div[3]/button")).click();
					break;
				case "Sauce Labs Onesie" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[5]/div[3]/button")).click();
				break;
				case "Test.allTheThings()T-Shrit (Red)" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[6]/div[3]/button")).click();
					break;
			 */
				}
				
			}
		}
		
		catch(Exception e) 
		{
				  //  Block of code to handle errors
				
		}	
			count++;
		}
		while(count<total);
		return ("Not found");
		
 }
}
