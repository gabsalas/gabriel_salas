import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class TC03_LOG_OUT {
	
	public static void main(String[] arg)
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\casa\\eclipse-workspace\\driver\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		Log_in log= new Log_in();
		driver.get("https://www.saucedemo.com");
		System.out.print(log.log_in("standard_user","secret_sauce",driver));
		
		Log_out logout= new Log_out();
		System.out.print(logout.log_out(driver)+"\n");
		driver.close();
	}

}
