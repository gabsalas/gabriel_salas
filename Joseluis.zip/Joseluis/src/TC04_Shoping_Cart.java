

	import org.openqa.selenium.WebDriver;
	import org.openqa.selenium.chrome.ChromeDriver;
	import org.openqa.selenium.By;

	public class TC04_Shoping_Cart 
	{
		public static void main(String[] arg)
		{
			
			System.setProperty("webdriver.chrome.driver","C:\\Users\\casa\\eclipse-workspace\\driver\\chromedriver.exe");
			WebDriver driver= new ChromeDriver();
			Log_in log= new Log_in();
			Shop_Cart log2= new Shop_Cart();
			driver.get("https://www.saucedemo.com");
			System.out.print(log.log_in("standard_user","secret_sauce",driver )+"\n");
			System.out.print(log2.Shop_Cart(driver)+"\n");
			driver.close();
			
		}
	}


