import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Checkout {
	public static  String  Checkout(WebDriver driver)  
	{
		
		//driver.get("https://www.saucedemo.com");
//		driver.findElement(By.id("menu_button_container")).click();
		
		 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/cart.html"))
				 {
			 	driver.findElement(By.xpath("//*[@id='cart_contents_container']/div/div[2]/a[2]")).click();
			 	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);//wait for 2 sec.
			 	 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/checkout-step-one.html"))
			 	 	{
			 		 return ("On shoop checkoutpage");
			 	 	}
			 	 else
			 	 	{
			 		return ("Incorrect page, is not the checkout page"); 
			 	 	}
				 }
		 else
		 {	
			 
			 
			//*[@id="login_button_container"]/div/form/h3/text()
			return ("Unown error ");
			 
		 }
		 
		 /*driver.close(); 
		 return ("NADA");*/
	 
	}
	public static  String  Check_items(String item,WebDriver driver, int total)  
	{
		
		int count=0;
		do
		{
			try 
			{
			if(	driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")) != null)
				{
				
					if(	driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")).getText().equals(item))
					{
						return (driver.findElement(By.xpath("//*[@id='item_"+Integer.toString(count) +"_title_link']/div")).getText()+ " Found");
			/*switch(item)
			{
				case "Sauce Labs Backpack" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[1]/div[3]/button")).click();
					break;
				case "Sauce Labs Bike Light" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[2]/div[3]/button")).click();
					break;
				case "Sauce Labs Bolt T-Shirt" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[3]/div[3]/button")).click();
					break;
				case "Sauce Labs Fleece Jacket" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[4]/div[3]/button")).click();
					break;
				case "Sauce Labs Onesie" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[5]/div[3]/button")).click();
				break;
				case "Test.allTheThings()T-Shrit (Red)" :
					driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[6]/div[3]/button")).click();
					break;
			 */
				}
				
					  //  Block of code to try
					}
			}
			
			catch(Exception e) 
			{
					  //  Block of code to handle errors
					
			}	
			count++;
		}
		while(count<total);
		return ("Not found");
	}
}
