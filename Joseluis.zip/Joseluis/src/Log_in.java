import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class Log_in 
{
	
	public  String  log_in(String user,String passw,WebDriver driver)
	{
		
		//driver.get("https://www.saucedemo.com");
		driver.findElement(By.id("user-name")).sendKeys(user);
		driver.findElement(By.id("password")).sendKeys(passw);
		driver.findElement(By.className("btn_action")).click();
		 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/inventory.html"))
				 {
			 		
			 	   return ("Correct Log in ");
				 }
		 else
		 {
			 
			if( driver.findElement(By.xpath("//*[@id='login_button_container']")).getText().equals("Epic sadface: Username and password do not match any user in this service") )
					{
				return ("User/password error");
					}
				
			 
			 
			//*[@id="login_button_container"]/div/form/h3/text()
			return ("Unown error ");
			 
		 }
		 /*driver.close(); 
		 return ("NADA");*/
	 
	}
}
