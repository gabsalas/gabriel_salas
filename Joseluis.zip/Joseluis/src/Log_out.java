import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Log_out {
	public  String  log_out(WebDriver driver)  
	{
		
		//driver.get("https://www.saucedemo.com");
//		driver.findElement(By.id("menu_button_container")).click();
		
		 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/inventory.html"))
				 {
			 	driver.findElement(By.xpath("//*[@id='menu_button_container']/div/div[3]/div/button")).click();
			 	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);//wait for 2 sec.
			 	driver.findElement(By.xpath("//*[@id='logout_sidebar_link']")).click();
			 	 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/index.html"))
			 	 	{
			 		 return ("Correct Log out");
			 	 	}
			 	 else
			 	 	{
			 		return ("Incorrect Log out"); 
			 	 	}
				 }
		 else
		 {
			 
			return ("Incorrect page");
		}
				
			 
			 
			//*[@id="login_button_container"]/div/form/h3/text()
		
			 
		 }
		 /*driver.close(); 
		 return ("NADA");*/
	 
	

	private void sleep(int i) {
		// TODO Auto-generated method stub
		
	}
}
