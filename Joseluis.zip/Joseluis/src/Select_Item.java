import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Select_Item {
	public static void Select_Item(String item,WebDriver driver)
	{
		switch(item)
		{
			case "Sauce Labs Backpack" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[1]/div[3]/button")).click();
				System.out.print("Sauce Labs Backpack selected\n");
			break;
			case "Sauce Labs Bike Light" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[2]/div[3]/button")).click();
				System.out.print("Sauce Labs Bike Light selected\n");
			break;
			case "Sauce Labs Bolt T-Shirt" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[3]/div[3]/button")).click();
				System.out.print("Sauce Labs Bolt T-Shirt selected\n" );
			break;
			case "Sauce Labs Fleece Jacket" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[4]/div[3]/button")).click();
				System.out.print("Sauce Labs Fleece Jacket selected\n" );
			break;
			case "Sauce Labs Onesie" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[5]/div[3]/button")).click();
				System.out.print("Sauce Labs Onesie selected\n" );
			break;
			case "Test.allTheThings() T-Shirt (Red)" :
				driver.findElement(By.xpath("//*[@id='inventory_container']/div/div[6]/div[3]/button")).click();
				System.out.print("Test.allTheThings() T-Shirt (Red) selected\n" );
			break;
		}
		
	}

	
}
