import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class User_data {
	
	public  void user_data()
	{
		
	}
	public  String data (WebDriver driver,String first,String last,String zip)
	{
		 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/checkout-step-one.html"))
		 {
			 (driver.findElement(By.id("first-name"))).sendKeys(first);
			 (driver.findElement(By.id("last-name"))).sendKeys(last);
			 (driver.findElement(By.id("postal-code"))).sendKeys(zip);
			 driver.findElement(By.xpath("//*[@id='checkout_info_container']/div/form/div[2]/input")).click();
			 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/checkout-step-two.html"))
			 {
			 return ("Mail data inserted \n");
			 }
			 else
			 {
				 driver.findElement(By.xpath("//*[@id='checkout_info_container']/div/form/h3")).getText();
				 
				//*[@id="checkout_info_container"]/div/form/h3
				 return ("error");
			 }
		 
		 }
		 else
		 {
			 return("incorrect page");
		 }
		 
	}
}
