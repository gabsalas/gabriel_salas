import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Shop_Cart {
	
	public static  String  Shop_Cart(WebDriver driver)  
	{
		
		//driver.get("https://www.saucedemo.com");
//		driver.findElement(By.id("menu_button_container")).click();
		
		 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/inventory.html"))
				 {
			 	driver.findElement(By.xpath("//*[@id='shopping_cart_container']")).click();
			 	driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);//wait for 2 sec.
			 	 if(driver.getCurrentUrl().contentEquals("https://www.saucedemo.com/cart.html"))
			 	 	{
			 		 return ("On shoop cart page");
			 	 	}
			 	 else
			 	 	{
			 		return ("Incorrect page, is not the cart page"); 
			 	 	}
				 }
		 else
		 {
			 
			if( driver.findElement(By.xpath("//*[@id='login_button_container']")).getText().equals("Epic sadface: Username and password do not match any user in this service") )
					{
				return ("User/password error");
					}
				
			 
			 
			//*[@id="login_button_container"]/div/form/h3/text()
			return ("Unown error ");
			 
		 }
		 /*driver.close(); 
		 return ("NADA");*/
	 
	}
}
